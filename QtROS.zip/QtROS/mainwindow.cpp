#include "mainwindow.h"
#include "./ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    server = new QTcpServer(this);

    if(!server->listen(QHostAddress::LocalHost, 5000)){
        ui->distancelabel->setText("ERROR");
    }else{
        ui->distancelabel->setText("LIVE...");
    }

    connect(server, &QTcpServer::newConnection, this, &MainWindow::onNewConnection);
}

void MainWindow::onNewConnection() {
    // Grab the socket connection
    socket = server->nextPendingConnection();
    connect(socket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
}

void MainWindow::onReadyRead() {
    // Read data from ROS Node
    QByteArray data = socket->readAll();

    // Update the GUI
        ui->distancelabel->setText(QString(data));
}

MainWindow::~MainWindow()
{
    delete ui;
}
